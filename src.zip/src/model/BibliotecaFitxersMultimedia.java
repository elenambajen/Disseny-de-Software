
package model;

import edu.ub.prog2.utils.AplicacioException;
import java.io.File;

/**
 *
 * @author Elena
 */
public class BibliotecaFitxersMultimedia extends CarpetaFitxers{
    
    /**
     * 
     */
    
    public BibliotecaFitxersMultimedia(){
    }
    
    /**
     * 
     * @param fitxer
     * @throws AplicacioException 
     */
    
    @Override
    public void addFitxer(File fitxer) throws AplicacioException{
        if(fitxers.contains((FitxerMultimedia) fitxer)) throw new AplicacioException("Fitxer Duplicat");
        else super.addFitxer(fitxer);
    }
    
    /**
     * 
     * @return 
     */
    
    @Override
    public boolean isFull(){
        return false;
    }
    
    /**
     * 
     * @return 
     */
    
    public boolean isEmpty(){
        return fitxers.isEmpty();
    }
    
}
