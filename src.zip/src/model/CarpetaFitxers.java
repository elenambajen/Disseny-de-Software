
package model;

import edu.ub.prog2.utils.*;
import java.io.File;
import java.util.ArrayList;
import java.io.Serializable;

/**
 *
 * @author Elena
 */
public class CarpetaFitxers implements InFileFolder, Serializable{

    ArrayList<FitxerMultimedia> fitxers;
    private final int _MAX = 100; 
    
    /**
     * 
     */
    
    public CarpetaFitxers(){
        this.fitxers = new ArrayList<>();
    }
    
    /**
     * 
     * @return 
     */
    
    @Override
    public int getSize(){
        return fitxers.size(); 
    }
    
    /**
     * 
     * @return 
     */
    
    @Override
    public boolean isFull(){
       return fitxers.size() == _MAX;
    }
    
    /**
     * 
     * @param fitxer
     * @throws AplicacioException 
     */
    
    @Override
    public void addFitxer(File fitxer)throws AplicacioException{
        if(!fitxer.exists()) throw new AplicacioException("Fitxer no existeix");
        
        if(!(fitxer instanceof FitxerReproduible)) throw new AplicacioException("No és un fitxer vàlid");
        
        if(this.isFull()) throw new AplicacioException("Tens la carpeta plena, prova d'esborrar algun altre fitxer");
        else fitxers.add((FitxerMultimedia) fitxer); 
    }  
    
    /**
     * 
     */
    
    @Override
    public void clear(){
        fitxers.clear();
    }
    
    /**
     * 
     * @param position
     * @return 
     */
    
    @Override
    public File getAt(int position){
        if(position < 0 || position > this.getSize()) return null;
        return fitxers.get(position);
    }
    
    /**
     * 
     * @param i
     * @throws AplicacioException 
     */
    
    public void removeFitxer(int i) throws AplicacioException{
        if(fitxers.isEmpty()) throw new AplicacioException("La carpeta està buida");
        
        if(i < 0 || i > this.getSize()) throw new AplicacioException("Posicio no trobada");
        else fitxers.remove(i);        
    }
    
    /**
     * 
     * @return 
     */
    
    @Override        
    public String toString(){
        String resum = "";
        resum = resum.concat("Carpeta Fitxers: \n");
        resum = resum.concat("================ \n");
        for(int i = 0; i < fitxers.size(); i++){
            String element = "\n";
            element = element.concat(((File)(fitxers.get(i))).toString());
            resum = resum.concat(element);
        } 
        return resum;
    }      

    @Override
    public void removeFitxer(File file) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
