
package model;

import edu.ub.prog2.utils.AplicacioException;
import java.io.File;

/**
 *
 * @author mariel
 */
public class AlbumFitxersMultimedia extends CarpetaFitxers{
    
    private final int max;
    String titol;
    
    /**
     * 
     * @param titol 
     */
    
    public AlbumFitxersMultimedia(String titol){
        super();
        this.titol = titol;
        this.max = 10;
    } 
    
    /**
     * 
     * @param titol
     * @param max 
     */
    
    public AlbumFitxersMultimedia(String titol, int max){
        super();
        this.titol = titol;
        this.max = max;
    }
    
    /**
     * 
     * @return 
     */
    
    @Override
    public boolean isFull(){
        return this.getSize() == max;
    }
    
    /**
     * 
     * @return 
     */
    
    public String getTitol(){
        return titol;
    }
    
    /**
     * 
     * @param fitxer
     * @throws AplicacioException 
     */
    
    @Override
    public void addFitxer(File fitxer) throws AplicacioException{
        super.addFitxer(fitxer);
    }  
    
}
