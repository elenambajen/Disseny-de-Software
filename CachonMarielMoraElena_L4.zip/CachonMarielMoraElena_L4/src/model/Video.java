
package model;

import controlador.Reproductor;
import edu.ub.prog2.utils.AplicacioException;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Elena
 */
public class Video extends FitxerReproduible{
    private final float alcada, amplada;
    private final float fps;
    
    /**
     * 
     * @param cami
     * @param nom
     * @param codec
     * @param durada
     * @param alcada
     * @param amplada
     * @param fps
     * @param r 
     */
    
    public Video(String cami, String nom, String codec, float durada, 
                 int alcada, int amplada, float fps, Reproductor r){
        super(cami, nom, codec, durada, r);
        this.alcada = alcada;
        this.amplada = amplada;
        this.fps = fps; 
    }
 
    /**
     * 
     */
    
    @Override
    public void reproduir(){
        try {
            this.getReproductor().reprodueix(this);
        } catch (AplicacioException ex) {
            Logger.getLogger(Video.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void setImatge(File fitxerImatge) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
