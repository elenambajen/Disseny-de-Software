
package model;

import java.io.File;
import java.util.Date;
import java.io.Serializable;

/**
 *
 * @author Elena
 */
public class FitxerMultimedia extends File implements Serializable{
    private String descripcio;
    
    /**
     * 
     * @param cami 
     */
    
    public FitxerMultimedia(String cami){
        super(cami);
    }
    
    /**
     * 
     * @return 
     */
    
    public Date getUltimaModificacio(){
        return new Date(super.lastModified());
    }
    
    /**
     * 
     * @return 
     */
    
    public String getCamiAbsolut(){
        return super.getAbsolutePath();
    }
    
    /**
     * 
     * @return 
     */
    
    public String getNomFitxer(){
        return super.getName(); 
    }
    
    /**
     * 
     * @return 
     */
    
    public String getExtensio(){
        int i = this.getNomFitxer().lastIndexOf('.');
        if (i > 0) return getNomFitxer().substring(i+1);
        return "";
    }
    
    /**
     * 
     * @return 
     */
    
    public String getDescripcio(){ 
         return this.descripcio; 
    }
    
    /**
     * 
     * @param descripcio 
     */
    
    public void setDescripcio(String descripcio){
        this.descripcio = descripcio;
    }
    
    /**
     * 
     * @param fitxerMultimedia
     * @return 
     */
    
    @Override
    public boolean equals(Object fitxerMultimedia){
        if(fitxerMultimedia == null) return false;
        FitxerMultimedia fitxer = (FitxerMultimedia) fitxerMultimedia;
        return  this.descripcio.equals(fitxer.getDescripcio()) 
                && super.equals(fitxerMultimedia);
    }
    
    /**
     * 
     * @return 
     */
    
    @Override
    public String toString(){
        //Descripció =    Nadal,    data=Thu    Jan    08    12:34:02    CET    2015,    
        //nom fitxer=carmen, ext=mp4, cami complet=F:\carmen.mp4
        String text = "";
        text = text.concat("Descripció = " + this.getDescripcio());
        text = text.concat(", data = " + this.getUltimaModificacio());
        text = text.concat(", nom fitxer = " + this.getNomFitxer());
        text = text.concat(", extensió = " + this.getExtensio());
        text = text.concat(", camí complet = " + this.getCamiAbsolut() + "\n");
        return text;
    }
    
}

