
package model;

import controlador.*;
import edu.ub.prog2.utils.AplicacioException;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Elena
 */
public class Dades implements Serializable{
    BibliotecaFitxersMultimedia b;
    ArrayList<AlbumFitxersMultimedia> llistaAlbums;
    boolean ciclic, aleatori;
    
    /**
     * 
     */
    
    public Dades(){
        this.b = new BibliotecaFitxersMultimedia();
        this.llistaAlbums = new ArrayList();
        this.aleatori = false;
        this.ciclic = true;
    }
    
    /**
     * 
     * @param fitxer
     * @throws AplicacioException 
     */
            
    public void save(File fitxer) throws AplicacioException{
        FileOutputStream font = null;
        ObjectOutputStream oos = null;
        try{
            font = new FileOutputStream(fitxer);
            oos = new ObjectOutputStream(font); 
            oos.writeObject(this);
        }catch(FileNotFoundException ex){
            throw new AplicacioException("Fitxer no trobat");
        }catch(IOException ex){
            throw new AplicacioException("Problema d'escriptura");
        }finally{
            try{
                if(font != null)font.close();
            }catch(IOException ex){
                throw new AplicacioException("No s'ha pogut tancar Fitxer");
            }
            try{
                if(oos != null) oos.close();
            }catch(IOException ex){
                throw new AplicacioException("No s'ha pogut tancar Fitxer");
            }
        }
    }
    
    /**
     * 
     * @param fitxer
     * @return
     * @throws AplicacioException 
     */
    
    public Dades load(File fitxer) throws AplicacioException{
        Dades dades = null;
        FileInputStream font = null;
        ObjectInputStream ois = null;
        try{
            font = new FileInputStream(fitxer); 
            ois = new ObjectInputStream(font); 
            dades = (Dades) ois.readObject();
        }catch(FileNotFoundException ex){
            throw new AplicacioException("Fitxer no trobat");
        }catch(IOException ex){
            throw new AplicacioException("Problema de lectura");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Dades.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try{
                if(font != null) font.close();
            }catch(IOException ex){
                throw new AplicacioException("No s'ha pogut tancar Fitxer");
            }
            try{
                if(ois != null) ois.close();
            }catch(IOException ex){
                throw new AplicacioException("No s'ha pogut tancar Fitxer");
            }
        }
        return dades;
    }
    
    /**
     * 
     * @param id
     * @throws AplicacioException 
     */
    
    public void esborrarFitxer(int id) throws AplicacioException{
        if(id < 0 || id > b.getSize()) throw new AplicacioException("Posicio no trobada");
        File fitxer = b.getAt(id);
        if(!llistaAlbums.isEmpty()){
            for(int i = 0; i < llistaAlbums.size(); i++){
                int j = 0;
                while(j < llistaAlbums.get(i).getSize()){
                    if(llistaAlbums.get(i).getAt(j).equals(fitxer)){
                        llistaAlbums.get(i).removeFitxer(j);
                    }
                    else j++;
                }
            }
        }
        b.removeFitxer(id);
    }
    
    /**
     * 
     * @return
     * @throws AplicacioException 
     */
    
    public List<String> mostrarBiblio() throws AplicacioException{
        List<String> llista = new ArrayList<>();
        for(int i = 0; i < b.getSize(); i++){
            String info = ((FitxerMultimedia )b.getAt(i)).getDescripcio();  
            llista.add(info);
        }
        return llista;
    }
    
    /**
     * 
     * @return
     * @throws AplicacioException 
     */
    
    public List<String> mostrarDadesBiblio() throws AplicacioException{
        List<String> llista = new ArrayList<>();
        for(int i = 0; i < b.getSize(); i++){
            String info = b.getAt(i).toString();  
            llista.add(info);
        }
        return llista;
    }
    
    /**
     * 
     * @param path
     * @param nomVideo
     * @param codec
     * @param durada
     * @param alcada
     * @param amplada
     * @param fps
     * @param r
     * @throws AplicacioException 
     */
    
    public void addVideo(String path, String nomVideo, String codec, 
                            float durada, int alcada, int amplada, float fps, Reproductor r)
                throws AplicacioException{
        Video video = new Video(path, nomVideo, codec, durada, alcada, amplada, fps, r);
        b.addFitxer(video);
    }
    
    /**
     * 
     * @param cami
     * @param camiImatge
     * @param nomAudio
     * @param codec
     * @param durada
     * @param kbps
     * @param r
     * @throws AplicacioException 
     */
    
    public void addAudio(String cami, String camiImatge, String nomAudio, 
                            String codec, float durada, int kbps, Reproductor r)
                throws AplicacioException{
        File fitxerImatge;
        if(camiImatge == null) fitxerImatge = null;
        else fitxerImatge = new File(camiImatge);
        Audio audio = new Audio(cami, fitxerImatge, nomAudio, codec, durada, kbps, r);
        b.addFitxer(audio);
    }

    // LLIURAMENT 3
    
    /**
     * 
     * @param titol
     * @throws AplicacioException 
     */
    
    public void addAlbum(String titol) throws AplicacioException{
        AlbumFitxersMultimedia album = getAlbum(titol);
        if(album != null) throw new AplicacioException("Album duplicat.");
        album = new AlbumFitxersMultimedia(titol);
        llistaAlbums.add(album);
    }
    
    /**
     * 
     * @param titol
     * @param size
     * @throws AplicacioException 
     */
    
    public void addAlbum(String titol, int size) throws AplicacioException{
        AlbumFitxersMultimedia album = getAlbum(titol);
        if(album != null) throw new AplicacioException("Album duplicat.");
        album = new AlbumFitxersMultimedia(titol, size);
        llistaAlbums.add(album);
    }
    
    /**
     * 
     * @return 
     */
    
    public List<String> mostrarAlbums(){
        List<String> llista = new ArrayList<>();
        for(int i = 0; i < llistaAlbums.size(); i++){
            String info = llistaAlbums.get(i).getTitol();
            llista.add(info);
        }
        return llista;
    }
    
    /**
     * 
     * @param titol
     * @throws AplicacioException 
     */
    
    public void borraAlbum(String titol) throws AplicacioException{
        llistaAlbums.remove(this.getAlbumEx(titol));
    }
    
    /**
     * 
     * @param titol
     * @return 
     */
    
    public boolean existAlbum(String titol){
        return llistaAlbums.contains(this.getAlbum(titol));
    }
    
    /**
     * 
     * @param titol
     * @param id
     * @throws AplicacioException 
     */
    
    public void addFitxer(String titol, int id) throws AplicacioException{
        if(id < 0 || id > b.getSize()) throw new AplicacioException("Posicio no trobada");
        File fitxer = b.getAt(id);
        getAlbumEx(titol).addFitxer(fitxer);
    }
    
    /**
     * 
     * @param titol
     * @return
     * @throws AplicacioException 
     */
    
    public List<String> mostra(String titol) throws AplicacioException{
        AlbumFitxersMultimedia album = getAlbum(titol);
        List<String> llista = new ArrayList();
        if(existAlbum(titol)){
            if(album.getSize() != 0){
                llista.clear();
                for(int i = 0; i < album.getSize(); i++){
                    String info = ((FitxerMultimedia) album.getAt(i)).getDescripcio();  
                    llista.add(info);
                }
            }
        }
        return llista;
    }
    
    /**
     * 
     * @param titol
     * @param id
     * @throws AplicacioException 
     */
    
    public void esborrarFitxer(String titol, int id) throws AplicacioException{
        getAlbumEx(titol).removeFitxer(id);
    }
    
    /**
     * 
     * @param b 
     */
    
    public void setAleatori(boolean b){
        this.aleatori = b;
    }
    
    /**
     * 
     * @param b 
     */
    
    public void setCicle(boolean b){
        this.ciclic = b;
    }
    
    /**
     * 
     * @return  
     */
    
    public boolean getAleatori(){
        return this.aleatori;
    }
    
    /**
     * 
     * @return  
     */
    
    public boolean getCicle(){
        return this.ciclic;
    }
    
    /**
     * 
     * @param r
     */
    
    public void setReproductor(Reproductor r){
        for(int i = 0; i<b.getSize();i++){
            FitxerReproduible f = (FitxerReproduible)b.getAt(i);
            f.setReproductor(r);
        }
    }
    
    /**
     * 
     * @return 
     */
    
    public BibliotecaFitxersMultimedia getBiblioteca(){
        return this.b;
    }
    
    /**
     * 
     * @param titol
     * @return 
     */
    
    public AlbumFitxersMultimedia getAlbum(String titol){
        AlbumFitxersMultimedia album = null;
        for(int i = 0; i < llistaAlbums.size(); i++){
            if(llistaAlbums.get(i).getTitol().equals(titol)) return llistaAlbums.get(i);
        }
        return album;
    }
    
    /**
     * 
     * @param titol
     * @return
     * @throws AplicacioException 
     */
    
    public AlbumFitxersMultimedia getAlbumEx(String titol) throws AplicacioException{
        for(int i = 0; i < llistaAlbums.size(); i++){
            if(llistaAlbums.get(i).getTitol().equals(titol)) return llistaAlbums.get(i);
        }
        throw new AplicacioException("Album no existeix.");
    }
    
}
