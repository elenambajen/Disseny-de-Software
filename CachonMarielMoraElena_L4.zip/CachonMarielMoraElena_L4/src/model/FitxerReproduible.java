
package model;

import controlador.*;
import java.io.File;

/**
 *
 * @author Elena
 */
public abstract class FitxerReproduible extends FitxerMultimedia{
    protected String codec;
    protected float durada;
    private transient Reproductor r;
    
    /**
     * 
     * @param cami
     * @param nom
     * @param codec
     * @param durada
     * @param r 
     */
    
    protected FitxerReproduible(String cami, String nom, String codec, float durada, Reproductor r){
        super(cami);
        super.setDescripcio(nom);
        this.codec = codec;
        this.durada = durada;
        this.r = r;  
    }
    
    /**
     * 
     */
    
    public abstract void reproduir();
    
    public abstract void setImatge(File fitxerImatge);
    
    /**
     * 
     * @return 
     */
    
    public Reproductor getReproductor(){
        return this.r;
    }
    
    /**
     * 
     * @param r 
     */
    
    public void setReproductor(Reproductor r){
        this.r = r;
    }
    
}
