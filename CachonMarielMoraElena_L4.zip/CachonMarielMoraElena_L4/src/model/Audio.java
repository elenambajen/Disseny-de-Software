package model;

import controlador.Reproductor;
import edu.ub.prog2.utils.AplicacioException;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Elena
 */
public class Audio extends FitxerReproduible {

    private File fitxerImatge;
    private final int kbps;

    /**
     *
     * @param cami
     * @param fitxerImatge
     * @param nom
     * @param codec
     * @param durada
     * @param kbps
     * @param r
     */
    public Audio(String cami, File fitxerImatge, String nom, String codec,
            float durada, int kbps, Reproductor r) {
        super(cami, nom, codec, durada, r);
        this.fitxerImatge = fitxerImatge;
        this.kbps = kbps;
    }

    /**
     *
     */
    @Override
    public void reproduir() {
        try {
            if(this.getImatge()==null)this.getReproductor().play(this);
            else this.getReproductor().play(this, this.getImatge());
        } catch (AplicacioException ex) {
            Logger.getLogger(Audio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @param fitxerImatge
     */
    @Override
    public void setImatge(File fitxerImatge) {
        this.fitxerImatge = fitxerImatge;
    }

    /**
     *
     * @return
     */
    public File getImatge() {
        return this.fitxerImatge;
    }

}
